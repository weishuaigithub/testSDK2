
#ifndef SPCryptoTool_h
#define SPCryptoTool_h

#define DEBUG_LOG

#ifdef DEBUG_LOG
#define LOGE(...) NSLog(__VA_ARGS__);NSLog(@"\n")
#else
#define LOGE(...)
#endif

__attribute__((visibility ("default")))
@interface SPCryptoTool : NSObject

/**
 * 将byte数组转换为NSData
 * byteArr   待转换的数组
 * len       数组长度
 */
+(NSData *) dataFromByteArr: (const void *)byteArr len:(NSInteger)len;

/**
 * 将NSString转换为NSData
 * str       待转换的NSString
 */
+(NSData *) dataFromHexNSString: (NSString *)str;


//AES
/**
 * 算法：AES
 * 加密函数，待加密的数据是NSString，加密结果使用base64编码
 * str  待加密的NSString
 * key  白盒密钥，由16进制字符串组成
 * iv   初始化向量，由16字节组成，使用CBC模式加密；如果传入nil，则表示使用ECB模式加密
 */
+(NSString * _Nullable) aesEncryptStringWithBase64: (NSString * _Nonnull)str iv:(NSData * _Nullable)iv;





/**
 * 算法：AES
 * 加密函数，待加密数据是NSData，加密结果是NSData
 * data 待加密的NSData
 * key  白盒密钥，由16进制字符串组成
 * iv   初始化向量，由16字节组成，使用CBC模式加密；如果传入nil，则表示使用ECB模式加密
 */
+(NSData *) aesEncryptData: (NSData *)data iv:(NSData *)iv;




/**
 * AES
 * 解密函数，待解密数据使用base64编码，解密结果是NSString
 * str  待解密的NSString
 * key  白盒密钥，由16进制字符串组成
 * iv   初始化向量，由16字节组成，使用CBC模式加密；如果传入nil，则表示使用ECB模式加密
 */
+(NSString * _Nullable) aesDecryptStringWithBase64: (NSString * _Nonnull)str iv:(NSData * _Nullable)iv;





/**
 * 算法：AES
 * 解密函数，待解密数据是NSData，解密结果是NSData
 * data 待加密的NSData
 * key  白盒密钥，由16进制字符串组成
 * iv   初始化向量，由16字节组成，使用CBC模式加密；如果传入nil，则表示使用ECB模式加密
 */
+(NSData *) aesDecryptData: (NSData *)data iv:(NSData *)iv;













@end

#endif /* SPCryptoTool_h */
