//
// Created by Vecentek on 2023/11/6.
//

#ifndef DECORELINK_DL_DKAPI_COMMUNICATE_H
#define DECORELINK_DL_DKAPI_COMMUNICATE_H

#include "dl_common_data.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * 该文件为C调用原生，原生实现函数
 */


/**
 * @brief 发送蓝牙数据
 * @param bytes 蓝牙数据
 * @param len  蓝牙数据长度
 * @param mac  蓝牙mac地址
 */
void DL_DKAPI_SendBle(uint8_t *bytes,
                      int len,
                      uint8_t mac[MAC_LEN]);

/**
 * @brief C解析后的蓝牙数据
 * @param body 蓝牙数据body部分
 * @param body_len 长度
 */
void DL_DKAPI_ReceiveMessage(uint8_t *body,
                             int body_len,
                             uint8_t mac[MAC_LEN]);
/**
 * @brief  返回SDK
 * @param cb_st 结果
 */
void DL_DKAPI_BackSDK(DL_CALLBACK_ST cb_st);

/**
 * @brief 返回SDK
 * @param cb_st 结果
 * @param buff 自定义数据
 * @param buff_len 自定义数据长度
 */
void DL_DKAPI_BackSDKWithBuff(DL_CALLBACK_ST cb_st,
                              uint8_t *buff,
                              int buff_len);
/**
 * @brief 日志传给SDK
 * @param msg
 * @param msg_len
 */
void DL_DKAPI_LogToSDK(uint8_t *msg,
                       int msg_len);


void(^ __nonnull DL_DKAPI_SendBleToSwift)(uint8_t * _Nullable bytes,
                                          int len,
                                          uint8_t mac[_Nullable MAC_LEN]);

void(^ __nonnull DL_DKAPI_ReceiveMessageToSwift)(uint8_t * _Nullable body,
                                                 int body_len,
                                                 uint8_t mac[_Nullable MAC_LEN]);

int(^ __nonnull DL_DKAPI_IsPrintLogToSwift)(void);

void(^ __nonnull DL_DKAPI_LogToSwift)(uint8_t *_Nullable, uint32_t);

void(^ __nonnull DL_DKAPI_BackSDKToSwift)(DL_CALLBACK_ST cb_st,uint8_t *_Nullable,uint32_t);
#ifdef __cplusplus
}
#endif
#endif //DECORELINK_DL_DKAPI_COMMUNICATE_H
