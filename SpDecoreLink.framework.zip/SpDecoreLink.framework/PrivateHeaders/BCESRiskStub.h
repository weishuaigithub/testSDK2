//
//  RiskManage.h
//  RiskManage
//
//  Created by bigdog on 2018/12/17.
//  Copyright © 2018年 bangcle. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for RiskManage.
FOUNDATION_EXPORT double BCERiskManageVersionNumber;

//! Project version string for RiskManage.
FOUNDATION_EXPORT const unsigned char BCERiskManageVersionString[];

NS_ASSUME_NONNULL_BEGIN

////online structure
typedef NSURLSessionAuthChallengeDisposition (^BCESRiskURLSessionDidReceiveAuthenticationChallengeBlock)
(NSURLSession * __nullable session,
 NSURLAuthenticationChallenge * __nullable challenge,
 NSURLCredential * _Nullable __autoreleasing * _Nullable credential);

typedef enum{
    kRisksCheckTypeUdid,
    kRisksCheckTypeDevInfo,
    kRisksCheckTypeApkInfo,
    kRisksCheckTypeStart,
    kRisksCheckTypeCrash,
    kRisksCheckTypeEmulator,
    kRisksCheckTypeLocation,
    kRisksCheckTypeRoot,
    kRisksCheckTypeHostFraud,
    kRisksCheckTypeDevices_Reuse,
    kRisksCheckTypeInject,
    kRisksCheckTypeDebugger,
    kRisksCheckTypeHttpProxy,
    kRisksCheckTypeVpnProxy,
    kRisksCheckTypeEnvCheck,
    kRisksCheckTypeScreenSharing,
    kRisksCheckTypeUnknown
} BCESRiskCheckType;
typedef void (^BCESCallBack)(NSDictionary * _Nullable dictionary,BCESRiskCheckType modularType);

////offline structure
typedef enum {
    kRisksEventUdid, //0
    kRisksEventRoot,
    kRisksEventEmulator,
    kRisksEventInject,
    kRisksEventDebug,
    kRisksEventHttpProxy,
    kRisksEventRiskFrame
} BCESRiskEvent;

typedef enum {
    kRisksActionMessage, // 只提示
    kRisksActionMessageThenQuit, // 提示后强制退出
    kRisksActionQuitOrMessage, // 提示后选择退出
    kRisksActionQuit // 直接强退
} BCESRiskAction;

typedef void (^BCESRiskEventHandler)(NSDictionary * _Nullable data, BCESRiskEvent riskType);

@interface BCESAlertContext : NSObject
@property (readonly) NSString* message; // 配置的策略弹框的内容
@property (readonly) NSString* title;  // 配置的策略弹框的标题
@property (readonly) BCESRiskAction action; // 配置的策略类型
@end

@interface BCESRiskStub : NSObject
////online feature
/// 不带返回初始化失败错误码的初始化方法（与带返回初始化失败错误码的初始化方法三选一即可）
/// @param key 初始化SDK所需的key
+ (void)initBangcleEverisk:(NSString *_Nonnull)key;

/// 带返回初始化失败错误码的初始化方法（与不带返回初始化失败错误码的初始化方法三选一即可）
/// @param key 初始化SDK所需的key
/// @return 初始化SDK的返回码
/// 0：表示初始化成功
/// 101: 表示初始化了多次
/// 102：key解析失败
/// 104：缺少BCESEveriskResource.bundle资源包
+ (NSInteger)initBangcleEveriskWithKey:(NSString *_Nonnull)key;

/// 带返回初始化失败错误码的初始化方法，与上面两个初始化方法功能一样，使用任意一个即可；
/// 使用此方法不用单独再调用注册数据回调方法
/// @param key 初始化SDK所需的key
/// @param listener 数据回调
/// /// 0：表示初始化成功
/// 101: 表示初始化了多次
/// 102：key解析失败
/// 104：缺少BCESEveriskResource.bundle资源包
+ (NSInteger)initBangcleEveriskWithKey:(NSString *_Nonnull)key withDataCallback:(BCESCallBack _Nullable)listener;

/// 在线探针注册数据回调方法（可选接口）
/// @param listener 数据回调
+ (void)registerServiceWithDataBlock:(BCESCallBack _Nullable )listener;

/// 探针进入后台模式，进入此模式探针会暂停运行（APP切换后台时建议调用此方法，可选接口）
+ (void)appEnterBackground;

/// 探针进入前台模式，进入此模式探针会继续运行（APP切换前台时建议调用此方法，可选接口）
+ (void)appEnterForeground;

/// 添加用户信息接口（可选接口，非必要不调用）
/// @param key 添加用户信息的key
/// @param value 添加用户信息的value
/// @return 是否添加成功
+ (BOOL)addExtraUserData:(NSString *_Nonnull)key withUserDatavalue:(NSString *_Nonnull)value;

/// 添加用户信息接口（可选接口，非必要不调用）
/// @param jsonData 字典类型的用户信息
/// @return 是否添加成功
+ (BOOL)addExtraUserData:(NSDictionary *_Nonnull)jsonData;

/// 添加用户ID（可选接口，非必要不调用）
/// @param value 用户id
+ (BOOL)addExtraUserID:(NSString *_Nonnull)value;

/// 添加用户ID相关信息（可选接口）
/// @param jsonData 字典类型的用户信息
/// @return 是否添加成功
+ (BOOL)addExtraUserIDWithDictionary:(NSDictionary *_Nonnull)jsonData;

/// 获取探针的版本号（可选接口，建议用下面的）
+ (NSString *)getEveriskVersion;

/// 获取探针的版本号（可选接口）
+ (NSString *)getEveriskSdkVersion;

/// 允许探针输出log（可选接口）
+ (void)enableBangcleLog;

/// 获取设备的UUID（可选接口）
+ (NSString *_Nullable)getEveriskUdid;

/// 获取探针的token（可选接口）
+ (NSDictionary *_Nullable)getEveriskToken;

/// 添加探针的服务器地址（可选接口）
/// @param downloadUrls 热更新地址（iOS版已废弃）
/// @param businessUrls 业务地址
+ (void)addUrl:(NSArray * _Nonnull )downloadUrls withBusinessUrl:(NSArray*_Nonnull)businessUrls;

/// 屏幕共享检测功能开关
/// @param enabled YES为开启，NO为关闭，默认值是YES
+ (void)setScreenSharingCheckerEnabled:(BOOL)enabled;

/// 执行一次屏幕共享检测任务
+ (void)checkScreenSharingStatus;

/// 检查设备当前是否处于通话状态 YES:处于通话状态 NO：没有处于通话状态
/// @param param 自定义参数，客户传递需要的参数,可以为空
+ (BOOL)checkCallStatus:(NSString *_Nullable)param;

/// 注册弹框策略回调接口（可选接口，用此接口以实现自定义弹框）
/// @param handler 弹框数据的回调block
+ (void)registerAlertActionHandler:(void (^)(BCESAlertContext * context))handler;

@property (readwrite, nonatomic, copy) BCESRiskURLSessionDidReceiveAuthenticationChallengeBlock _Nullable sessionDidReceiveAuthenticationChallenge;





////offline feature

/// 初始化离线探针接口（与下面的初始化接口二选一即可）
+ (void)initOfflineBangcleEveriskFromBundle;

/// 带有数据回调参数的离线探针初始化接口，使用此函数进行初始化就无需再调用注册离线数据回调接口
/// @param handler 数据回调的block
+ (void)initOfflineBangcleEveriskFromBundleWithDataCallback:(BCESRiskEventHandler)handler;

/// 注册离线数据回调接口（可选接口）
/// @param handler 数据回调的block
+ (void)registerOfflineEventHandler:(BCESRiskEventHandler)handler;

+ (void)addFilterStrings:(NSArray*)strings;

/// 获取威胁信息接口（可选接口）
+ (NSDictionary *_Nullable)getEnvInfo;

////inner usage
+ (BCESRiskStub *_Nullable)sharedManager;
@end

NS_ASSUME_NONNULL_END
