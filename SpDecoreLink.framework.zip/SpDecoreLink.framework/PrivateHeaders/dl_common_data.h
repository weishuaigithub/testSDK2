//
// Created by Vecentek on 2023/11/3.
//

#ifndef DECORELINK_DL_COMMON_DATA_H
#define DECORELINK_DL_COMMON_DATA_H

#include <stdint.h>

#define MAX_LOG_BUFF_LEN 1024
#define MAX_BODY_BUFF_LEN 512
#define MSG_BUFF_LEN 256
#define ARGS_BUFF_LEN 256
#define MAC_LEN 6
#define SK_LEN 16
#define IV_LEN SK_LEN

#define CRC_ERROR 0x13
typedef enum {
    DL_SUCCESS = 0,
    DL_FAILED = -1,
    DL_ERROR = -8
}DL_RTN;

typedef struct {
    int code;
    uint8_t msg[MSG_BUFF_LEN];
    int msg_len;
} DL_CALLBACK_ST;


typedef struct {
    uint8_t buff[ARGS_BUFF_LEN];
    int buff_len;
} ARGS_ST;

typedef enum
{
    BLE_CONNECTED = 0,
    BLE_DISCONNECTED,
    BLE_OFF,
}BLE_STATE;

#endif //DECORELINK_DL_COMMON_DATA_H
