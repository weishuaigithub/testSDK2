//
// Created by Vecentek on 2023/11/2.
//

#ifndef DECORELINK_DL_DKAPI_H
#define DECORELINK_DL_DKAPI_H

#include "dl_dkapi_communicate.h"

#ifdef __cplusplus
extern "C" {
#endif
/**
 * 该文件为原生调用
 */


/**
 * @brief 获取C库版本
 * @return
 */
const char *DL_DKAPI_GetVersion();

/**
 * @brief 设置蓝牙状态
 * @param state
 * @param mac BLE_OFF时候mac地址为[0x00,0x00,0x00,0x00,0x00,0x00]
 */
void DL_DKAPI_SetBleState(BLE_STATE state,
                          uint8_t mac[MAC_LEN]);

/**
 * @brief 设置会话密钥与向量
 * @param mac 蓝牙mac地址
 * @param session_key
 * @param iv
 */
void DL_DKAPI_SetICCESessionKey(uint8_t mac[MAC_LEN],
                                uint8_t session_key[SK_LEN],
                                uint8_t iv[IV_LEN]);

/**
 * @brief 发送蓝牙报文
 * @param mac 蓝牙mac地址
 * @param body 报文body部分
 * @param body_len
 * @param encrypt 是否加密
 * @param direction 方向指示位
 * @param sync 同步指示位
 * @return
 */
DL_RTN DL_DKAPI_SendMessage(uint8_t mac[MAC_LEN],
                            uint8_t *body,
                            int body_len,
                            uint8_t encrypt,
                            uint8_t direction,
                            uint8_t sync);

/**
 * @brief 蓝牙收到的数据
 * @param mac 蓝牙mac地址
 * @param bytes
 * @param bytes_len
 */
void DL_DKAPI_ReceiveBle(uint8_t mac[MAC_LEN],
                         uint8_t *data,
                         int data_len);



#ifdef __cplusplus
}
#endif
#endif //DECORELINK_DL_DKAPI_H
